package com.maimob.server.encoder;

import java.io.IOException;

public class CEFormatException extends IOException
{
	public CEFormatException(String s)
	{
		super(s);
	}
}
