package com.maimob.server.encoder;

import java.io.IOException;

public class CEStreamExhausted extends IOException
{

}
