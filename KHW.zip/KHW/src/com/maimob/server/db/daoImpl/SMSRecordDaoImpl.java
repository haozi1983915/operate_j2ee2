package com.maimob.server.db.daoImpl;

import org.springframework.stereotype.Repository;

import com.maimob.server.db.common.BaseDaoHibernate5;
import com.maimob.server.db.entity.SMSRecord;

//注入
@Repository
public class SMSRecordDaoImpl extends BaseDaoHibernate5<SMSRecord>{

}
