package com.maimob.server.importData.dao;

import java.sql.ResultSet;

public interface IDao {
	
	public Object Daologic(ResultSet rs);
	
	
	
	
	
	
	
	
	
	
	

}
