package com.maimob.server.importData.dao;
 

public class LoansDao extends Dao {

	public LoansDao() {
		
		super("db_loans");
//		db_operate
	}
	
	
	
	
}
